// @umml/noc-lite :: sim/env-meter
// STATUS: extraction target (Phase 1) — NOT YET WIRED.
// The working implementation currently lives inline in /index.html (index.html:1128 (tail section)).
// Owns after extraction: ENV_IMPACT strip: kW draw, PUE, grid CI, routing offset
// See docs/ARCHITECTURE.md for the full extraction map and module contract.
export const EXTRACTION_PENDING = true;
