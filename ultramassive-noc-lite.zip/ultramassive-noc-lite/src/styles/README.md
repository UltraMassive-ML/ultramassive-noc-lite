# Styles

The shipped stylesheet is **compiled** Tailwind (CLI v3.4.17), inlined in `index.html`
(marker comment: `compiled with Tailwind CLI`). Do not hand-edit it.

To change styling: edit classes in markup, then run `../../build/build.sh` and paste
`build/compiled.css` back into the marked `<style>` block. Custom non-Tailwind rules
(`.glass-panel`, `.scan-container`, keyframes) live in the second `<style>` block and
are hand-maintained.
