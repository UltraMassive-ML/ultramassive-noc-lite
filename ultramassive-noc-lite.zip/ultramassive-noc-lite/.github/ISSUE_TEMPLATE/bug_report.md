---
name: Bug report
about: Something renders wrong, throws, or violates its stated contract
title: "[BUG] <deck or surface>: <one line>"
labels: bug
---

**Deck / surface** (ROUTING_NOC, QUANTUM_OPS, ENV_IMPACT strip, sign-in gate, ...):

**Steps to reproduce**
1.
2.

**Expected vs. actual**

**Environment**: browser+version · OS · served (`http.server`) or `file://`

**Console output** (paste verbatim):

**Screenshot / GIF** (if visual):
