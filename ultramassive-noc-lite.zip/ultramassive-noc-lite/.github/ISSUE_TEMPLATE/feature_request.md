---
name: Feature request
about: A new deck, control, metric, or integration
title: "[FEAT] <one line>"
labels: enhancement
---

**Problem / motivation** — what can't you do or see today?

**Proposed behavior** — controls, telemetry, math panel, citations you'd expect.

**Deck placement** — existing deck or a new tab? Free-tier visible or gated?

**Literature** — if this simulates a real dynamic, cite the source we should ground it in.
