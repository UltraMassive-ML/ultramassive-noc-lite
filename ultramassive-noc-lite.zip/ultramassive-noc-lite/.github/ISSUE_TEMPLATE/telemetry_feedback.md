---
name: Telemetry-accuracy feedback
about: A simulated dynamic or interpretation panel misrepresents the cited literature
title: "[TELEMETRY] <panel>: <claim at issue>"
labels: telemetry-accuracy, documentation
---

**Panel** (e.g., QUANTUM_OPS → Logical Error Rate):

**The claim at issue** (quote the interpretation text or formula):

**Why it's wrong / imprecise** — functional form, constant, missing regime, misread citation:

**Source** (paper/section/equation — required):

**Suggested correction** (formula or wording):

> We treat citation and functional-form accuracy as a ship-blocking bug class.
