## What & why

Closes #

## Checklist
- [ ] Both inline scripts pass `node --check`
- [ ] Rebuilt CSS via `build/build.sh` if any classes changed
- [ ] All 13 decks + ENV strip render (served via `http.server`)
- [ ] New/changed interpretation panels cite real, verifiable sources
- [ ] Honesty markers (synthetic telemetry, demo auth) intact
- [ ] Screenshots/GIF attached for visual changes
