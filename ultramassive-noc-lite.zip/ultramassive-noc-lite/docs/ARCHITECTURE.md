# Architecture & Extraction Map

`index.html` is the single source of truth (1,440 lines). The table below maps every
functional unit to its **verified line anchor** in the current monolith and its Phase-1
destination module. Anchors were grepped from the shipped file at scaffold time; re-run
`grep -n "function <name>" index.html` to re-verify after edits.

## Layout of the monolith

| Region | Lines | Contents |
|---|---|---|
| Head / compiled CSS | 1–~60 | Compiled Tailwind (CLI 3.4.17) inline `<style>`, KaTeX + fonts links |
| Custom CSS | ~60–120 | `.glass-panel`, `.scan-container`, keyframes (`scanline`, `fadeUp`, `flowData`) |
| Site sections | ~120–265 | header/nav, hero, mission, **technologies**, autotelic, NOC gate + plans + API request |
| NOC deck markup | 268–652 | 13 views (anchors below), ENV_IMPACT strip, modals (payload, env, sign-in) |
| Main script | ~700–1330 | nav/ROI/math-bg + NOC logic + simulation engines |
| Consent+auth script | ~1330–1440 | legal modals, cookie consent, operator auth |

## Deck markup anchors

| View | Line | View | Line |
|---|---|---|---|
| `view-routing` | 268 | `view-ds` | 506 |
| `view-drift` | 331 | `view-cyber` | 522 |
| `view-perf` | 357 | `view-bigdata` | 539 |
| `view-mleng` | 372 | `view-quantum` | 556 |
| `view-aieng` | 442 | `view-mlops` | 573 |
| — | — | `view-devops` | 589 |
| — | — | `view-cloud` | 605 |
| — | — | `view-scires` | 621 |

## Function → module extraction map

| Function / state | Line | Destination module | Contract notes |
|---|---|---|---|
| `executeNOCRouting()` | 874 | `src/engine/router.js` | Emits `RouteDecision {tier, possibility, necessity, qsfp_risk, rationale}`; pure given (payload, constraints) |
| Π/N evaluation inside routing + stream | 874 / 909 | `src/engine/possibilistic.js` | `band(payload, ctx) → {pi, n}`; escalation rule `pi < τ ⇒ tierUp` |
| `streamMathematicalTelemetry()` | 909 | `src/engine/telemetry-stream.js` | Async generator of KaTeX blocks; UI-agnostic |
| `animatePerformanceGraphs()` + series | 937 | `src/sim/eng-core.js` (loop owner) | Owns the 500 ms tick; calls the two updaters below |
| `updateEngGraphs()` + `ENG` | 1003 | `src/sim/eng-core.js` | ML_ENG / AI_ENG series + controls |
| `updateDomainGraphs()` + `ENG2` | 1128 | `src/sim/domains.js` | 8 domain decks; ENV meter section splits to `env-meter.js` |
| `engPath/engSet/engTxt/push2` | 983 | `src/ui/svg-charts.js` | Pure SVG-path helpers; the only DOM touchpoints for charts |
| `mountNOC()` / tier locking | 801 | `src/ui/auth-gate.js` | Auth check is the single mount choke point — keep it that way |
| `unlockNOC()` | 844 | `src/ui/auth-gate.js` | Delegates to `mountNOC` |
| `doSignIn()/signOutNOC()/renderAuthStatus()` | 1408 | `src/ui/auth-gate.js` | Session cookie `um_user`; swap for OIDC later |
| `switchView()` | 850 | `src/ui/views.js` | Also enforces dev-tier lock (`target !== 'routing'`) |
| `loadPreset()/updateSDMLabel()/togglePayloadModal()` | 865± | `src/ui/views.js` | Console chrome |
| `initMathBackground()` | 756 | `src/ui/views.js` (or own module) | Hero KaTeX particle field |
| `calcROI()/roiAggr()` | 739 | stays in site layer | Marketing page, not console |
| `requestAPIAccess()` | 829 | `src/ui/auth-gate.js` | Demo key issuance (`um_dev_*`) — replace with API call |
| Legal/cookie/consent (`openLegal`, `cookieConsent`, …) | 1379–1400 | site layer module | Independent of NOC |
| `toggleEnvModal()` | 1124 | `src/sim/env-meter.js` | Methodology modal |

## Extraction ground rules

1. **Behavior-lock first.** Before extracting a module, capture its current output for a
   fixed seed/tick sequence; the extracted module must reproduce it byte-for-byte.
2. **`mountNOC` stays the only mount path.** Every entry (plans, key, Enter key) already
   funnels through it; do not add parallel paths.
3. **Charts never own state.** `svg-charts.js` stays pure; series state lives in `sim/`.
4. **CSS is compiled, not authored.** Class changes ⇒ `build/build.sh` ⇒ paste. The
   second `<style>` block (custom rules) is the only hand-edited CSS.


## Module dependency graph & extraction roadmap

See README Figures 5–6 for the rendered versions; reproduced here so this document
stands alone. Solid arrows = target imports; the three invariants: `svg-charts` is a
pure leaf, `auth-gate` is the sole mount path, `engine/*` has no UI imports.

```mermaid
graph LR
    subgraph engine
      R[router.js] --> P[possibilistic.js]
      R --> TS[telemetry-stream.js]
    end
    subgraph sim
      EC[eng-core.js] --> D[domains.js]
      D --> EV[env-meter.js]
    end
    subgraph ui
      V[views.js] --> SC[svg-charts.js]
      AG[auth-gate.js] --> V
    end
    D --> SC
    R --> V
```
