# Contributing

Thanks for breaking things on purpose — that's the point of this repo.

1. **File first.** Open an issue with the matching template before large PRs.
2. **One deck per PR** where possible; include before/after screenshots or a GIF.
3. **Citation integrity is ship-blocking.** Any claim in an interpretation panel must
   trace to a real, verifiable source. PRs that add panels must add citations; PRs
   that find citation errors get priority review.
4. **Honesty markers stay.** The synthetic-telemetry and demo-auth disclosures in the
   README, gate, and methodology modal must survive refactors.
5. **CSS workflow:** never hand-edit the compiled block — `./build/build.sh` and paste.
6. Verify before pushing: both inline scripts pass `node --check`, brace/paren balance
   holds, and `python3 -m http.server` renders all 13 decks and the ENV strip.
